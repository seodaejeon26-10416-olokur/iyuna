const fs=require('node:fs');const file=__dirname+'/chaeum/dist/app.js';let app=fs.readFileSync(file,'utf8');
const before='<a class="shop-link coupang" href="${url1}" target="_blank" rel="noopener noreferrer"><span>coupang</span><strong>쿠팡에서 가격 확인 ↗</strong><small>상품 검색 결과로 이동</small></a>';
const after='<div class="shop-link coupang"><span>coupang</span><a class="coupang-home" href="https://www.coupang.com/" target="_blank" rel="noopener noreferrer">쿠팡 홈 열기 ↗</a><small>검색 주소가 제한되면 홈에서 검색하세요.</small><div class="keyword-copy"><input id="coupang-keyword" aria-label="쿠팡에 붙여넣을 검색어" value="${esc(q)}" readonly><button type="button" id="copy-coupang-keyword">검색어 복사</button></div></div>';
if(!app.includes(before))throw Error('Expected Coupang markup missing');app=app.replace(before,after);
app=app.replace("const q=shoppingQuery(i),url1='https://www.coupang.com/np/search?q='+encodeURIComponent(q),url2=",'const q=shoppingQuery(i),url2=');
const needle=" const form=$('#offer-form');";if(!app.includes(needle))throw Error('Expected form missing');
app=app.replace(needle,` $('#copy-coupang-keyword').onclick=async()=>{const field=$('#coupang-keyword');try{if(!navigator.clipboard?.writeText)throw Error('clipboard_unavailable');await navigator.clipboard.writeText(field.value);$('#copy-coupang-keyword').textContent='복사 완료';toast('쿠팡 홈의 검색창에 붙여넣어 주세요')}catch{field.focus();field.select();toast('검색어를 선택했어요. Ctrl+C 또는 길게 눌러 복사해 주세요')}};\n`+needle);
fs.writeFileSync(file,app);
