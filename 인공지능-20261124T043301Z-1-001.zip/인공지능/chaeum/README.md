# 채움

생필품 관리, 소진 예상, 쿠팡·네이버 API 상품 가격 조회, 구매 링크 연결을 제공하는 웹사이트입니다. 개인 기록은 현재 브라우저에 저장됩니다.

## 실행

node build-worker.mjs
node test-api.mjs
node preview-worker.mjs

로컬 미리보기: http://127.0.0.1:4174

화면 소스는 dist/index.html, dist/app.js, dist/style.css, dist/shopping.css이며 서버 API는 worker/api.mjs입니다. build-worker.mjs가 화면 파일을 포함한 Worker를 dist/server/index.js로 생성합니다. Worker 배포이므로 hosting.json에 static 필드를 두지 않습니다.

## 실제 API 연결

Sites 서버의 비밀 환경변수로 아래 네 가지를 등록하고 저장 버전을 다시 배포합니다. 비밀값을 화면 소스, Git, hosting.json, 채팅에 넣지 마세요.

- COUPANG_ACCESS_KEY
- COUPANG_SECRET_KEY
- NAVER_CLIENT_ID
- NAVER_CLIENT_SECRET

현재는 사용자가 연동 코드만 완성하도록 요청했으므로 실제 키는 등록하지 않았습니다. 쿠팡은 파트너스 상품 검색 권한이 있는 키가 필요합니다. 판매자용 Open API 키와 구분됩니다. 네이버는 쇼핑 검색 API의 Client ID/Secret 인증 방식을 사용합니다. 계정별 API 권한과 발급 경로에 따라 확인이 필요할 수 있습니다.

## 기능과 한계

생필품 등록/수정/삭제, 소진 예상과 사이트 내 알림, API 상품 검색, 구매 페이지 연결, 저장 가격의 쿠폰·배송비·단위당 가격 비교, 구매 기록, 월별 통계와 JSON 백업을 지원합니다. 첫 방문의 6개 품목은 샘플입니다.

상품 API는 조회 당시의 상품가를 제공합니다. 개인별 쿠폰, 배송비, 포인트와 최종 결제액을 자동 확정하지 않습니다. 전체 용량은 사용자가 확인하여 입력합니다. 같은 검색은 최대 60초 동안 서버 메모리에서 재사용하며 조회 시각을 유지합니다. 사이트가 닫힌 동안의 푸시와 기기 간 기록 동기화는 제공하지 않습니다.

실제 키가 없으므로 외부 API 인증 성공은 아직 검증하지 않았습니다. test-api.mjs는 모의 응답으로 HMAC 서명, 키 미등록 처리, API 정규화, 안전한 구매 링크, 캐시, 외부 오류와 비밀값 미노출을 검증합니다.

네이버 공식 문서: https://developers.naver.com/docs/serviceapi/search/shopping/shopping.md
쿠팡 파트너스 API 문서 (로그인 필요): https://partners.coupang.com/#/api

쿠팡 검색 주소에서 사용권한 제한 화면이 확인되어 일반 연결 버튼은 정상 접속을 확인한 쿠팡 홈으로 연결합니다. 검색어 복사 버튼을 누르고 쿠팡 홈의 검색창에 붙여넣으면 됩니다. API 응답과 직접 저장한 상품의 상세 구매 링크는 그대로 제공합니다.
