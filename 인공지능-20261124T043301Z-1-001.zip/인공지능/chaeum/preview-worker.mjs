import http from 'node:http';import fs from 'node:fs';
const source=fs.readFileSync('dist/server/index.js','utf8');const {default:worker}=await import('data:text/javascript;base64,'+Buffer.from(source).toString('base64'));
const env={};
http.createServer(async(req,res)=>{try{const r=await worker.fetch(new Request('http://127.0.0.1:4174'+req.url,{method:req.method}),env);res.writeHead(r.status,Object.fromEntries(r.headers));res.end(Buffer.from(await r.arrayBuffer()))}catch{res.writeHead(500);res.end('Preview error')}}).listen(4174,'127.0.0.1',()=>console.log('Local: http://127.0.0.1:4174'));
