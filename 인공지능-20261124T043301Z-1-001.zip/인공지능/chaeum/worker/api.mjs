const encoder=new TextEncoder();
const allowedProviders=['coupang','naver'];
export function providerStatus(env){return {coupang:!!(env.COUPANG_ACCESS_KEY&&env.COUPANG_SECRET_KEY),naver:!!(env.NAVER_CLIENT_ID&&env.NAVER_CLIENT_SECRET)}}
export function cleanText(v){return String(v||'').replace(/<[^>]*>/g,'').replace(/&quot;/g,'"').replace(/&amp;/g,'&').replace(/&#39;|&apos;/g,"'").replace(/&lt;/g,'<').replace(/&gt;/g,'>')}
export function publicUrl(value){try{const u=new URL(value);if(u.protocol!=='https:'||u.username||u.password)return null;return u.href}catch{return null}}
export async function authorization(path,query,env,now=new Date()){
 const date=now.toISOString().replace(/[-:]/g,'').replace(/\.\d{3}Z$/,'Z').slice(2);
 const key=await crypto.subtle.importKey('raw',encoder.encode(env.COUPANG_SECRET_KEY),{name:'HMAC',hash:'SHA-256'},false,['sign']);
 const signed=await crypto.subtle.sign('HMAC',key,encoder.encode(date+'GET'+path+query));
 const signature=Array.from(new Uint8Array(signed),b=>b.toString(16).padStart(2,'0')).join('');
 return `CEA algorithm=HmacSHA256, access-key=${env.COUPANG_ACCESS_KEY}, signed-date=${date}, signature=${signature}`;
}
export async function fetchProducts(provider,q,env,fetcher=fetch){
 let response,rows;
 const checkedAt=new Date().toISOString();
 if(provider==='naver'){
  const params=new URLSearchParams({query:q,display:'10',sort:'sim',exclude:'used:rental'});
  response=await fetcher('https://openapi.naver.com/v1/search/shop.json?'+params,{headers:{'X-Naver-Client-Id':env.NAVER_CLIENT_ID,'X-Naver-Client-Secret':env.NAVER_CLIENT_SECRET},signal:AbortSignal.timeout(12000)});
 }else{
  const path='/v2/providers/affiliate_open_api/apis/openapi/products/search';
  const query=new URLSearchParams({keyword:q,limit:'10'}).toString();
  response=await fetcher('https://api-gateway.coupang.com'+path+'?'+query,{headers:{Authorization:await authorization(path,query,env)},signal:AbortSignal.timeout(12000)});
 }
 if(!response.ok){const code=response.status===401||response.status===403?'unauthorized':response.status===429?'rate_limited':'upstream_error';throw new Error(code)}
 const body=await response.json();
 if(provider==='naver'){
  if(!Array.isArray(body.items))throw new Error('upstream_error');
  rows=body.items.map(p=>({id:String(p.productId),name:cleanText(p.title),price:Number(p.lprice),url:publicUrl(p.link),shop:cleanText(p.mallName)||'네이버쇼핑',provider,checkedAt}));
 }else{
  if(body.rCode!=='0'&&body.rCode!==0)throw new Error('provider_rejected');
  if(!Array.isArray(body.data?.productData))throw new Error('upstream_error');
  rows=body.data.productData.map(p=>({id:String(p.productId),name:cleanText(p.productName),price:Number(p.productPrice),url:publicUrl(p.productUrl),shop:'쿠팡',provider,checkedAt,isRocket:!!p.isRocket,freeShipping:p.isFreeShipping===true}));
 }
 return rows.filter(p=>p.url&&Number.isFinite(p.price)&&p.price>0);
}
const json=(data,status=200)=>Response.json(data,{status,headers:{'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
const messages={unauthorized:'API 키 또는 상품 검색 이용 권한을 확인해 주세요.',rate_limited:'조회 한도에 도달했어요. 잠시 후 다시 확인해 주세요.',provider_rejected:'쿠팡에서 요청을 승인하지 않았어요. 키와 검색 API 권한을 확인해 주세요.',upstream_error:'구매처 응답을 받지 못했어요. 잠시 후 다시 시도해 주세요.'};
const recent=new Map(),pending=new Map();
export async function handleApi(request,env,fetcher=fetch){
 const u=new URL(request.url);
 if(request.method!=='GET')return json({error:'method_not_allowed'},405);
 if(u.pathname==='/api/status')return json({providers:providerStatus(env)});
 if(u.pathname!=='/api/prices')return json({error:'not_found'},404);
 const q=(u.searchParams.get('q')||'').trim(),provider=u.searchParams.get('provider');
 if(!allowedProviders.includes(provider)||!q||q.length>100)return json({error:'invalid_query',message:'검색어는 1~100자로 입력해 주세요.'},400);
 if(!providerStatus(env)[provider])return json({error:'not_configured',message:'서버에 API 키를 등록하면 가격을 조회할 수 있어요.'},503);
 const key=provider+':'+q;
 const cached=recent.get(key);if(cached&&Date.now()-cached.time<60000)return json({...cached.data,cached:true});
 try{
  if(!pending.has(key))pending.set(key,fetchProducts(provider,q,env,fetcher));
  const data={products:await pending.get(key),checkedAt:new Date().toISOString(),provider};
  if(recent.size>=100)recent.delete(recent.keys().next().value);
  recent.set(key,{time:Date.now(),data});return json({...data,cached:false});
 }
 catch(error){let code=error.name==='TimeoutError'?'upstream_error':error.message;return json({error:messages[code]?code:'upstream_error',message:messages[code]||messages.upstream_error},502)}
 finally{pending.delete(key)}
}
