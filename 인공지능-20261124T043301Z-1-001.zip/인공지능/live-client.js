
let liveController;
function startLivePrices(item){
 if(liveController)liveController.abort();
 const form=$('#live-search'),box=$('#live-results');let results=[];
 async function load(){
  if(liveController)liveController.abort();const controller=new AbortController();liveController=controller;
  const query=form.elements.query.value.trim();if(!query)return;
  const button=form.querySelector('button');button.disabled=true;button.textContent='조회 중…';box.innerHTML='<p class="form-hint">구매처에서 가격을 확인하고 있어요…</p>';
  try{
   const settled=await Promise.all(['coupang','naver'].map(async provider=>{try{const response=await fetch('/api/prices?'+new URLSearchParams({q:query,provider}),{signal:controller.signal});const body=await response.json();if(!response.ok)return {provider,error:body.message||'조회할 수 없어요.'};return {provider,products:body.products||[]}}catch(e){if(e.name==='AbortError')throw e;return {provider,error:'조회 서버에 연결할 수 없어요.'}}}));
   if(controller.signal.aborted||!box.isConnected)return;
   results=settled.flatMap(s=>s.products||[]).sort((a,b)=>a.price-b.price);
   box.innerHTML=settled.filter(s=>s.error).map(s=>`<div class="api-error"><b>${s.provider==='coupang'?'쿠팡':'네이버'}</b> · ${esc(s.error)}</div>`).join('')+(results.length?`<div class="live-list">${results.map((p,k)=>`<article class="live-item"><div><span class="live-provider">${esc(p.shop)}${p.isRocket?' · 로켓배송':''}</span><h4>${esc(p.name)}</h4><small>${esc(new Date(p.checkedAt).toLocaleTimeString('ko-KR',{timeZone:'Asia/Seoul'}))} 조회 · 배송비·쿠폰 별도 확인</small><strong>${money(p.price)}원</strong></div><div class="live-actions"><a href="${esc(safeUrl(p.url)||'#')}" class="primary" target="_blank" rel="noopener noreferrer sponsored">구매하러 가기 ↗</a><button class="text-button" data-live-save="${k}">이 상품 비교에 추가</button></div></article>`).join('')}</div>`:settled.every(s=>!s.error)?'<p class="saved-empty">검색 결과가 없어요. 상품명이나 용량을 바꿔보세요.</p>':'<p class="form-hint">API 연결 전에도 위의 구매처 링크와 직접 가격 등록 기능은 사용할 수 있어요.</p>');
   box.querySelectorAll('[data-live-save]').forEach(b=>b.onclick=()=>{const p=results[Number(b.dataset.liveSave)],f=$('#offer-form');f.reset();f.elements.offerId.value='';f.elements.shop.value=p.shop;f.elements.price.value=p.price;f.elements.url.value=p.url;$('#offer-editor').open=true;toast('상품의 전체 용량과 배송비·쿠폰을 확인하고 저장하세요');f.elements.amount.focus()});
  }catch(e){if(e.name!=='AbortError')box.textContent='가격 조회에 실패했어요. 다시 시도해 주세요.'}finally{if(!controller.signal.aborted&&button.isConnected){button.disabled=false;button.textContent='가격 새로 조회'}}
 }
 form.onsubmit=e=>{e.preventDefault();load()};load();
}
